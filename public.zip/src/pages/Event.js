import React from 'react'

const Event = () => {
  return (
    <div>
      <h1></h1>
    </div>
  )
}

export default Event
