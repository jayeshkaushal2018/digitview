import React from 'react'

const Dashboad = () => {
  return (
    <div>
      <h1>Dashboard</h1>
    </div>
  )
}

export default Dashboad
