import React from 'react'

const Product = () => {
  return (
    <div>
      <h1>Product</h1>
    </div>
  )
}

export default Product
