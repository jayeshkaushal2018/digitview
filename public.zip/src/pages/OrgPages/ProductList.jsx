import React from 'react'

const ProductList = () => {
  return (
    <div>
      <h1>ProductList</h1>
    </div>
  )
}

export default ProductList
